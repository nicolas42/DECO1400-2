# Balloon Technology

The balloon option works about how you'd expect. You blow up a balloon and then you let it go and the balloon makes that farting noise as it jets off around the room. As unlikely as it may seem the balloon option is the most popular option at the moment.

Nobody has made a balloon which will fly fast enough to get into orbit.  Balloons also run out of air quickly, they can pop, and also they reduce in size which would make flying in them cramped.  So we had to get something else. Explosions!

Yes the only way people have found to get into space is by sitting on-top of explosions.  Not a short explosion like you're used to but one that lasts for minutes.  There's many problems with this which occur to people such as, if you sit on an explosion won't you explode?  And how do I keep an explosion going once it's exploded?  Well all these and more will be discussed and  not answered to any degree.  Read on... ~~Also the explosion has to point downwards. If it points upwards at any time then you're in trouble!~~  

Giant spray can.  It's pressurized, made of metal, and with a single button it will eject fast moving gases (with a little modification) out of the back like the balloon.  But, as you wearily point out, spray cans don't fly around the room so how will they ever make it to space!?!