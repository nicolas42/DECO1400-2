# Gravity

Gravity is the weakest of the fundamental forces.  It's about a trillion trillion trillion times weaker than the other ones.  But it doesn't cancel out like they do, it just keeps on adding up.  That's why it's important when dealing with planet sized things.

Everything pulls on everything else just a little bit. Your neighbour is currently pulling on you with an invisible force.  The earth is bigger than everything else so everything seems to get pulled towards it.  But thats just because it weighs about a trillion trillion times more than you.  The reason why you can only fly in your dreams and probably can't dunk in basketball is gravity. Newton invented it a while back.

- gravity strength vs distance from earth

    Gravity (like most things) likes to spread out.  As the gravity tries to get to you

Although astronauts in orbit look like they're floating they're actually continually falling towards the Earth. The earth pulls on the astronauts about as strongly as it does to you but they keep on missing the Earth as they fall.  They are going so fast sideways as they hurtle towards the ground they miss.  Then they miss again and again. This continuous falling but never crashing into the thing is called orbiting like an orb or circle.

- Elliptical orbits

    We orbit in squished circles called ellipses that are shaped a bit like eggs. Nature is pretty random and the things that didn't rotate in somethimg a bit circulqr hit eahhother until they did.  None of the planets orbits can hit eachother  they're the only planets left after the Old ones decided to fight eaxhother. 

    The moon originally got into fisticuffs with the earth.  <Gif of collision>. This is why it looks at us with the same face. <it's rotational velocity is the same as the Earth's. This is why there's a Dark side of the moon. Pink Floyd.  Which can only be seen from a spaceship going around the back. 

- You could at 1 meter off the ground
    - <if there’s no atmosphere to slow you down you could orbit at one meter off the ground. (Also no hills to crash into) moon footage? Ksp footage?
- Dynamic wind resistance

    If you've ever put your hand out of the window of car on the highway you'll know that the air can exert quite a strong force if you're going fast.  This effect gets worse the faster you go.

    Once you've gone up high enough so that the air is less of a problem then all you need to do is go fast enough sideways. To do that there are two main strategies which I’ll call the balloon and elephant techniques. <black books ref>